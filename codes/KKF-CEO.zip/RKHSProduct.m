function M = RKHSProduct(y1, y2, p)
    syms x
    
    leny1 = size(y1,2);
    leny2 = size(y2,2);
    M = zeros(leny1, leny2);
    for i = 1:leny1
        for j = 1:leny2
            for m = 1:size(y1, 1)
                %f = exp(- p*(x - y1(m,i))^2 - p*(x - y2(m,j))^2);
                %M(i,j) = M(i,j) + int(f, -inf, inf);
                %M(i,j) = M(i,j) + sqrt(pi)*exp(-(y1(m,i)-y2(m,j))^2*p/2)/sqrt(2*p) + sqrt(pi/p) + a(m) - b(m);
                %M(i,j) = M(i,j) + sqrt(pi)*exp(-(y1(m,i)-y2(m,j))^2*p/2)/sqrt(2*p);
                M(i,j) = M(i,j) + exp(-p*(y1(m,i) - y2(m,j))^2);
            end
        end
    end
end
