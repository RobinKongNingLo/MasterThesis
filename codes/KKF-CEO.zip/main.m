%System initialization
m = 200;
c1 = 0.4;
c2 = 0.84;
c3 = 6.0;
c4 = 1.0;
x = zeros(2, m+2); %Data: [x0, x1, ..., xm, xm+1]
x(:,1) = [1;0]; %x0 = [1 0]^T
%Build the system
for i = 1:m+1
    w = c1 - c3/(1 + x(1,i)^2 + x(2,i)^2);
    x(1,i+1) = c4 + c2*(x(1,i)*cos(w) - x(2,i)*sin(w));
    x(2,i+1) = c2*(x(1,i)*sin(w) + x(2,i)*cos(w));
end

%Parameters
sig = 10^(-3);
lambda = 10^(-4);
q = 1;
r = 12.5;
noise_snr = -3;

%Initialize the experiment
iterations = 1;
MSE = zeros(1, iterations);
SNR = zeros(1, iterations);
%x_pred_mean = zeros(size(x,1), size(x,2)-1);
tic
for j = 1:iterations
    %Add noise to the system
    y = awgn(x, noise_snr, 'measured');
    fprintf('iteration %i / %d', j, iterations);

    %parameters used in estimaation
    y1 = y(:,2:m+1); %[y1, ..., ym]
    y2 = y(:,3:m+2); %[y2, ..., ym+1]

    kernel_size = median(pdist(transp(y(1,:)))); %Gaussian kernel size sigma is median of pairwise distance of training data
    p = 1/(2*kernel_size^2);

    %x = x(1,:);
    %y1 = y1(1,:);
    %y2 = y2(1,:);
    %y = y(1,:);

    %Initialization
    K = RKHSProduct(y1, y1, p);
    M = RKHSProduct(y2, y2, p);
    T = RKHSProduct(y1, y2, p);
    L = inv(K + sig * m * eye(m));
    a = L * RKHSProduct(y1, y(:,1), p);
    P_ = lambda * L * K * transp(L);
    x_pred = zeros(size(x,1), size(x,2)-1);
    
    %Filtering    
    for i = 1:m+1
        G = inv((q + r) * eye(m) + P_*M) * P_;
        %G = inv((q + r) * eye(m)) * P_;
        P = r / (q+r)*P_ - r/(q+r)*G*M*P_ - (q*r)/(q+r)*G;
        %P = r / (q+r)*P_;
        b = (r/(q+r)*eye(m) - r/(q+r)*G*M)*a + r/(q+r)*G*RKHSProduct(y2, y(:,i+1), p);
        %b = r/(q+r)*a;
        x_pred(:,i) = y2*b + q/(q+r)*y(:,i+1);
        a = L*T*b + q/(q+r)*L*RKHSProduct(y1, y(:,i+1), p);
        P_ = L*T*P*transp(T)*transp(L) + (q*r)/(q+r)*L*K*transp(L); 
        %P_ = (q*r)/(q+r)*L*K*transp(L); 
    end
    
    error = x(1,2:m+2)-x_pred(1,:);
    MSE(1, j) = sum(error.^2)/(m+1);
    SNR(1, j) = snr(x(1,2:m+2), error);
    %x_pred_mean = x_pred_mean + x_pred;
end
toc
% MSE_mean = mean(MSE);
% MSE_std = std(MSE);
% SNR_mean = mean(SNR);
% SNR_std = std(SNR);

plot(y(2:m+1), 'Color', '#EDB120')
hold on
plot(x_pred(1,1:m), 'Color',	'#D95319')
plot(x(1,2:m+1) , 'Color', '#0072BD')


legend('Noisy Signal', 'Estimated Signal','True Signal', 'Location','northwest')
%x_pred_mean = x_pred_mean ./ iterations;
%plot
% figure(1)
% plot(x_pred_mean(1,:))
% hold on
% plot(x(1,2:202))
% legend('predicted x1', 'true x1')
% 
% figure(2)
% plot(x_pred_mean(2,:))
% hold on
% plot(x(2,2:202))
% legend('predicted x2', 'true x2')
