time_step = 0.01;
tspan = [0:time_step:20];
x0 = [1 1];
[t,X] = ode45(@(t,X) vanDerPol(t,X), tspan, x0);

noise_snr = 20;

N = size(X,1)-1;
x = X;
X = awgn(X, noise_snr, 'measured');
X1 = X(1:N,1);
X2 = X(2:N+1,1);

Ke = zeros(N);
gam = 1;
for n = 1:N
    for n2 = 1:N
        Ke(n,n2) = exp(-gam*sum((X1(n,:)-X1(n2,:)).^2)) * exp(-gam*sum((X2(n,:)-X2(n2,:)).^2));
    end
end

converged = 0;
% Assign all objects into one cluster except one
% Kernel K-means is *very* sensitive to initial conditions.  Try altering
% this initialisation to see the effect.
K = 8;
sglmat = zeros(1,K+1);
sglmat(1) = 1;
Z = repmat(sglmat,N,1);
pos_step = N/K;
for k = 1:K
    Z(pos_step*k-pos_step/2,1) = 0;
    Z(pos_step*k-pos_step/2,k+1) = 1;
end

di = zeros(N,K);
cols = {'r','b'};

while ~converged
    Nk = sum(Z,1);
    for k = 1:K+1
        % Compute kernelised distance
        di(:,k) = diag(Ke) - (2/(Nk(k)))*sum(repmat(Z(:,k)',N,1).*Ke,2) + ...
            Nk(k)^(-2)*sum(sum((Z(:,k)*Z(:,k)').*Ke));
    end
    oldZ = Z;
    Z = (di == repmat(min(di,[],2),1,K+1));
    Z = 1.0*Z;
    if sum(sum(oldZ~=Z))==0
        converged = 1;
    end
end

%%

lastidx = find(Z(1,:) == 1);
bin_sum1 = 0;
bin_sum2 = 0;
time_sum = 0;
num_ele = 0;
y1 = [];
y2 = [];
time = [];
Lambda_ele = [];

for i = 1:size(Z,1)
    idx = find(Z(i,:) == 1);
    if idx ~= lastidx
        y1 = [y1 bin_sum1/num_ele];
        y2 = [y2 bin_sum2/num_ele];
        time = [time round(time_sum/num_ele)];
        Lambda_ele = [Lambda_ele num_ele];
        bin_sum1 = 0;
        bin_sum2 = 0;
        time_sum = 0;
        num_ele = 0;
        lastidx = idx;
    end
    bin_sum1 = bin_sum1 + X1(i);
    bin_sum2 = bin_sum2 + X2(i);
    time_sum = time_sum + i;
    num_ele = num_ele + 1;
end

%%

kernel_size = median(pdist(transp(y1))); %Gaussian kernel size sigma is median of pairwise distance of training data
p = 1/(2*kernel_size^2);
m = size(y1,2);
sig = 10^(-3);
lambda = 10^(-4);
q = 1;
r = 3;
y = [y1 y2(m)];

%Initialization
Lambda = diag(transp(Lambda_ele));

K = RKHSProduct(y1, y1, p);
M = RKHSProduct(y2, y2, p);
T = RKHSProduct(y1, y2, p);
L = Lambda * inv(K*Lambda + sig * m * eye(m));
a = L * RKHSProduct(y1, y(:,1), p);
P_ = lambda * L * K * transp(L);
x_pred = zeros(1, m);
x_test = imresize(x, [m+2,2]);
x_test = transp(x_test);
x_test = x_test(1,:);
y_test = awgn(x_test, noise_snr, 'measured');
tic
%Filtering    
for i = 1:m
    G = inv((q + r) * eye(m) + P_*M) * P_;
    %G = inv((q + r) * eye(m)) * P_;
    P = r / (q+r)*P_ - r/(q+r)*G*M*P_ - (q*r)/(q+r)*G;
    %P = r / (q+r)*P_;
    b = (r/(q+r)*eye(m) - r/(q+r)*G*M)*a + r/(q+r)*G*RKHSProduct(y2, y(:,i+1), p);
    %b = r/(q+r)*a;
    x_pred(:,i) = y2*b + q/(q+r)*y(:,i+1);
    a = L*T*b + q/(q+r)*L*RKHSProduct(y1, y(:,i+1), p);
    P_ = L*T*P*transp(T)*transp(L) + (q*r)/(q+r)*L*K*transp(L); 
    %P_ = (q*r)/(q+r)*L*K*transp(L); 
end
toc

x_time = transp(x(time, 1));
time = time*time_step;

error = x_time - x_pred;
MSE = sum(error.^2)/(m+1);
SNR = snr(x_time, error);

%%
plot(tspan, x(:,1)')
hold on
plot(time,x_pred)
legend('original', 'predicted')
